﻿Imports System.IO

' Shell Author: Bob Desilets
' Modified by: Tien Le
' Module name: frmRM3000
' Last Modified date: 25-April-2020
' Module description: form 3000 time mgr

Public Class frmRM3000

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        If lstSyncTimeBibs.Items.Count > 0 Then
            frmRM0000.btnResultsMgr.Enabled = True
        Else
            frmRM0000.btnResultsMgr.Enabled = False
        End If
        frmRM0000.Show()
        Me.Hide()

    End Sub

    Private Sub btnSyncTimesBibs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSyncTimesBibs.Click
        ' This button is disabled until both Times and Bibs have been entered.
        ' The associated list box is invisible until this buttom is pressed
        ' This routine merges Position | Time | Bib #

        Dim intPostion As Integer
        Dim index As Integer = 0
        Dim intPlacing As Integer = 1

        lstSyncTimeBibs.Items.Clear()
        For Each item As String In lstTimeEntry.Items
            Dim strRunner As String = "Runner Not Found"
            Dim strSchool As String = "School Not Found"

            lstBibs.SelectedIndex = index
            intPostion = InStr(lstBibs.SelectedItem, "- ")
            strRunner = Trim(Mid(lstBibs.SelectedItem, intPostion + 2))
            ' Find School and Runners by stepping through lstPlayers
            For Each item2 As String In frmRM2000.lstPlayers.Items
                ' Sample row layout -- lstRoster.Items.Add("A-SHS")
                If strRunner = Mid(item2, 1, 3) Then
                    strSchool = Mid(item2, 5)
                End If
            Next
            lstSyncTimeBibs.Items.Add(intPlacing & " - " & item & " - " & strRunner & " - " & strSchool)
            index += 1
            intPlacing += 1
            Me.Refresh()
        Next
    End Sub

    Private Sub btnEnterResults_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEnterResults.Click
        'Load time button
        Dim textIn As StreamReader = New StreamReader(New FileStream(txtFilePath.Text, FileMode.OpenOrCreate, FileAccess.Read))

        Dim strRow As String
        Dim bolFoundCode As Boolean = False

        'Clear Team listbox
        lstTimeEntry.Items.Clear()

        Do While textIn.Peek <> -1
            Me.Refresh()
            strRow = textIn.ReadLine.Trim
            If Not bolFoundCode Then
                If "# TIME FILE" = UCase(Mid(strRow, 1, 11)) Then
                    bolFoundCode = True
                End If
            Else
                If Mid(strRow, 1, 2) <> "# " Then
                    lstTimeEntry.Items.Add(strRow)
                End If
            End If
        Loop
        'Set focus on the first item
        lstTimeEntry.SelectedIndex = 0

        'Check if it's sync-able
        If lstTimeEntry.Items.Count > 0 And lstBibs.Items.Count > 0 Then
            btnSyncTimesBibs.Enabled = True
        Else
            btnSyncTimesBibs.Enabled = False
        End If
    End Sub

    Private Sub txtFilePath_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtFilePath.TextChanged
        If txtFilePath.Text.Length > 0 Then
            btnEnterResults.Enabled = True
        Else
            btnEnterResults.Enabled = False
        End If
    End Sub

    Private Sub btnEnterBib_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEnterBib.Click
        'Enter Bib one by one.
        Dim strInput As String
        Dim bolDup As Boolean
        Dim intStart As Integer
        Dim strTest As String
        'Clear Bib list
        lstBibs.Items.Clear()
        For index As Integer = 1 To lstTimeEntry.Items.Count
            strInput = InputBox("Enter the BIB for position #" & index, "Race Mgr Enter BIB")
            Do
                bolDup = False
                For Each strBIB_Test As String In lstBibs.Items
                    intStart = InStr(1, strBIB_Test, "-")
                    strTest = Mid(strBIB_Test, intStart + 2, 3)
                    'lstBibs.Items.Add(strTest)
                    If strTest = strInput Then
                        bolDup = True
                    End If
                Next
                If Not bolDup Then
                    lstBibs.Items.Add(index & " - " & strInput)
                Else
                    strInput = InputBox("Enter a different BIB for position number " & index, "Race Mgr Enter BIB")
                End If
            Loop While bolDup
        Next

        'Set focus on the first item
        lstBibs.SelectedIndex = 0
        'Check if it's sync-able
        If lstTimeEntry.Items.Count > 0 And lstBibs.Items.Count > 0 Then
            btnSyncTimesBibs.Enabled = True
        Else
            btnSyncTimesBibs.Enabled = False
        End If
    End Sub

    Private Sub BtnBibAuto_Click(sender As Object, e As EventArgs) Handles btnBibAuto.Click
        Dim strPath As String = "C:\Bob\BIBPositions.txt"

        Dim strRow As String
        Dim bolFoundCode As Boolean = False
        Dim intCounter As Integer = 1
        Dim intStart As Integer
        Dim strTest As String
        Dim arrCheck(10000) As String
        Dim index As Integer = 0

        Dim textIn As StreamReader = New StreamReader(New FileStream(strPath, FileMode.OpenOrCreate, FileAccess.Read))

        Do While textIn.Peek <> -1
            Me.Refresh()
            strRow = textIn.ReadLine.Trim
            arrCheck(index) = Mid(strRow, 1, 3)
            index += 1
        Loop

        Dim numCheck As Integer = 0

        For i As Integer = 0 To arrCheck.Length - 1
            If Not arrCheck(i) Is Nothing Then
                Dim l As Integer = Array.LastIndexOf(arrCheck, arrCheck(i))
                If l <> i Then
                    numCheck += 1
                End If
            End If
        Next

        Dim textIn2 As StreamReader = New StreamReader(New FileStream(strPath, FileMode.OpenOrCreate, FileAccess.Read))

        If numCheck <> 0 Then
            lstBibs.Items.Clear()
            lstBibs.Items.Add("FOUND DUPLICATE")
            lstBibs.Items.Add("PLEASE FIX INPUT FILE")
        Else
            'Add all lines to lstbox
            Do While textIn2.Peek <> -1
                Me.Refresh()
                strRow = textIn2.ReadLine.Trim
                lstBibs.Items.Add(intCounter & " - " & Mid(strRow, 1, 3))
                intCounter += 1
            Loop
        End If

        'Set focus on the first item
        lstBibs.SelectedIndex = 0

        'Check if it's sync-able
        If lstTimeEntry.Items.Count > 0 And lstBibs.Items.Count > 0 Then
            btnSyncTimesBibs.Enabled = True
        Else
            btnSyncTimesBibs.Enabled = False
        End If
    End Sub
End Class