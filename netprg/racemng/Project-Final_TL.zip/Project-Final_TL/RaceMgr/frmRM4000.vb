﻿Imports System.IO

' Shell Author: Bob Desilets
' Modified by: Tien Le
' Module name: frmRM4000
' Last Modified date: 25-April-2020
' Module description: form 4000 result mgr

Public Class frmRM4000

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        frmRM0000.Show()
        Me.Hide()
    End Sub

    Private Sub btnCalculateResults_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCalculateResults.Click
        'Calculate the result

        'Enable the Archive button
        btnArchive.Enabled = True
        'Clear the list box
        lstTeamResults.Items.Clear()

        Dim strDayTime As String = Format(Now, "General Date")
        Dim strFullName As String = "Tien Le's Race Manager - CIS 223"
        Dim strOneTab As String = "    "
        Dim strFiveTab As String = "                    "
        Dim strResultLine As String
        Dim index As Integer = 0
        Dim intPositionStart As Integer
        Dim intPositionEnd As Integer
        Dim intPostitionTest As Integer
        Dim intPoints(7) As Integer
        Dim intTotalPoints As Integer = 0
        Dim strPosition As String
        Dim strTime As String
        Dim strBIB As String
        Dim strSchool As String
        Dim strRunnerFname As String
        Dim strRunnerLname As String
        For Each str1000_item As String In frmRM1000.lstTeam.Items
            'Outer loop
            Dim str1000_SchoolCode As String = Trim(Mid(str1000_item, 1, InStr(1, str1000_item, "|") - 1))
            For Each str3000_item As String In frmRM3000.lstSyncTimeBibs.Items
                'Inner loop
                'Find the vertical bar
                intPositionEnd = InStr(1, str3000_item, "|")
                'Find the 3rd (-) sign
                intPositionStart = InStr(1, str3000_item, "-")
                intPostitionTest = InStr(intPositionStart + 1, str3000_item, "-")
                intPositionStart = InStr(intPostitionTest + 1, str3000_item, "-")
                intPositionStart += 2
                'Copy the school code from (index) of SYNC listbox
                Dim str3000_SchoolCode As String = Trim(Mid(str3000_item, intPositionStart, intPositionEnd - intPositionStart))
                'Check for if it's the same school
                If str1000_SchoolCode = str3000_SchoolCode Then
                    'Add point to it if it's the same school
                    intPoints(index) = Convert.ToInt32(Mid(str3000_item, 1, 2))
                    If index < 5 Then
                        intTotalPoints += intPoints(index)
                    End If
                    index += 1
                End If
            Next

            'Default spacing
            Dim strSpace As String = "         "

            If str1000_SchoolCode.Trim.Length = 3 Then
                strSpace = "          "
            ElseIf str1000_SchoolCode.Trim.Length = 4 Then
                strSpace = "         "
            ElseIf str1000_SchoolCode.Trim.Length = 5 Then
                strSpace = "        "
            End If

            If intTotalPoints > 0 And index = 7 Then
                'Seven Runners
                strResultLine = $"{intTotalPoints:D6}    {str1000_SchoolCode}{strSpace}{intPoints(0):D3}    {intPoints(1):D3}    {intPoints(2):D3}    {intPoints(3):D3}    {intPoints(4):D3}    {intPoints(5):D3}    {intPoints(6):D3}"
                lstTeamResults.Items.Add(strResultLine)
            End If

            If intTotalPoints > 0 And index = 6 Then
                'Six Runners
                strResultLine = $"{intTotalPoints:D6}    {str1000_SchoolCode}{strSpace}{intPoints(0):D3}    {intPoints(1):D3}    {intPoints(2):D3}    {intPoints(3):D3}    {intPoints(4):D3}    {intPoints(5):D3}    ---"
                lstTeamResults.Items.Add(strResultLine)
            End If

            If intTotalPoints > 0 And index = 5 Then
                'Five Runners
                strResultLine = $"{intTotalPoints:D6}    {str1000_SchoolCode}{strSpace}{intPoints(0):D3}    {intPoints(1):D3}    {intPoints(2):D3}    {intPoints(3):D3}    {intPoints(4):D3}    ---    ---"
                lstTeamResults.Items.Add(strResultLine)
            End If
            'Reset index and all values
            intTotalPoints = 0
            intPoints(0) = 0
            intPoints(1) = 0
            intPoints(2) = 0
            intPoints(3) = 0
            intPoints(4) = 0
            intPoints(5) = 0
            intPoints(6) = 0
            index = 0
        Next

        ' Sort all items added previously.
        lstTeamResults.Sorted = True
        ' Stop sorting all items
        lstTeamResults.Sorted = False

        'Adding the labels
        lstTeamResults.Items.Insert(0, strFullName & strFiveTab & strDayTime)
        lstTeamResults.Items.Insert(1, "")
        lstTeamResults.Items.Insert(2, strFiveTab & "      T E A M   R E S U L T S")
        lstTeamResults.Items.Insert(3, "Points" & strOneTab & "Team Code" & strOneTab & "P-1" & strOneTab & "P-2" &
                                 strOneTab & "P-3" & strOneTab & "P-4" & strOneTab & "P-5" & strOneTab & "P-6" & strOneTab & "P-7")
        lstTeamResults.Items.Add("")
        lstTeamResults.Items.Add(strFiveTab & "I N D I V I D U A L   R E S U L T S")
        lstTeamResults.Items.Add("Position" & strOneTab & "  Time  " & strOneTab &
                                 "BIB" & strOneTab & "School" & strOneTab & "Runner")

        'Getting information from frmRM3000 lstSync
        For Each str3000_item As String In frmRM3000.lstSyncTimeBibs.Items
            intPositionStart = 1
            intPositionEnd = InStr(intPositionStart, str3000_item, "-")
            strPosition = Mid(str3000_item, intPositionStart, 2)

            intPositionStart = intPositionEnd + 2
            intPositionEnd = InStr(intPositionStart, str3000_item, "-")
            strTime = Mid(str3000_item, intPositionStart, 8)

            intPositionStart = intPositionEnd + 2
            intPositionEnd = InStr(intPositionStart, str3000_item, "-")
            strBIB = Mid(str3000_item, intPositionStart, 3)

            intPositionStart = intPositionEnd + 2
            intPositionEnd = InStr(intPositionStart, str3000_item, "|")
            strSchool = Mid(str3000_item, intPositionStart, intPositionEnd - intPositionStart)

            intPositionStart = intPositionEnd + 1
            intPositionEnd = InStr(intPositionStart, str3000_item, "|")
            strRunnerFname = Mid(str3000_item, intPositionStart, intPositionEnd - intPositionStart)

            intPositionStart = intPositionEnd + 1
            intPositionEnd = InStr(intPositionStart, str3000_item, "|")
            strRunnerLname = Mid(str3000_item, intPositionStart)

            'Default spacing
            Dim strSpace As String = "      "

            If strSchool.Trim.Length = 3 Then
                strSpace = "       "
            ElseIf strSchool.Trim.Length = 4 Then
                strSpace = "      "
            ElseIf strSchool.Trim.Length = 5 Then
                strSpace = "     "
            End If

            strResultLine = $"      {strPosition}    {strTime}    {strBIB}    {strSchool}{strSpace}{strRunnerFname} {strRunnerLname}"
            lstTeamResults.Items.Add(strResultLine)
        Next

    End Sub

    Private Sub btnArchive_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnArchive.Click
        ' Create new file.
        Dim strPath As String = "C:\Bob\RaceMgr-Result_TienLe.txt"
        Using writer As StreamWriter =
            New StreamWriter(strPath)
            For Each strRow As String In lstTeamResults.Items
                writer.WriteLine(strRow)
            Next
        End Using
        MsgBox("Successfullly created C:\Bob\RaceMgr-Result_TienLe.txt")
    End Sub
End Class