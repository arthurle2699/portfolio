﻿Imports System.IO

' Shell Author: Bob Desilets
' Modified by: Tien Le
' Module name: frmRM1000
' Last Modified date: 25-April-2020
' Module description: form 1000 team mgr
Public Class frmRM1000
    Private Sub btnLoadTeams_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoadTeam.Click
        ' This routine loads the lstTeam box from an ASCII .txt file
        ' # School [School Code | Name | Coach F-Name| Coach L-Name | AD F-Name | AD L-Name]
        Dim strRow As String
        Dim bolFoundCode As Boolean = False
        Dim bolEndCode As Boolean = False
        Dim bolFoundDup As Boolean = False
        Dim intPosition As Integer
        Dim intPosition2 As Integer
        Dim strTeamCodeIn As String

        Dim textIn As StreamReader =
            New StreamReader(New FileStream(txtFilePath.Text, FileMode.OpenOrCreate, FileAccess.Read))

        ' Clear Team listbox
        lstTeam.Items.Clear()

        Do While textIn.Peek <> -1 And Not bolEndCode
            Me.Refresh()
            strRow = textIn.ReadLine.Trim
            If Not bolFoundCode Then
                If "# SCHOOL " = UCase(Mid(strRow, 1, 9)) Then
                    bolFoundCode = True
                End If
            Else
                If Mid(strRow, 1, 2) <> "# " Then
                    For Each item As String In lstTeam.Items
                        intPosition = InStr(1, strRow, "|")
                        strTeamCodeIn = Mid(strRow, 1, intPosition - 1)
                        intPosition2 = InStr(1, item, strTeamCodeIn)
                        If intPosition2 > 0 Then
                            bolFoundDup = True
                            MsgBox("Found Duplicate School Code: " & strTeamCodeIn)
                        End If
                    Next

                    If Not bolFoundDup Then
                        lstTeam.Items.Add(strRow)
                    Else
                        lstTeam.Items.Add("DUPLICATE School Code: " & strRow)
                        lstTeam.Items.Add("Please correct input file and reload teams")
                        bolEndCode = True
                    End If
                Else
                    bolEndCode = True
                End If
            End If
        Loop
        'Set focus on the first item
        lstTeam.SelectedIndex = 0
    End Sub

    Private Sub BtnAddRunners_Click(sender As Object, e As EventArgs) Handles btnAddRunners.Click
        'Adding team one by one so I don't have to make a new form :)
        Dim intPosition As Integer
        Dim strTeamCodeIn As String
        Dim bolFoundDup As Boolean = False
        Dim bolEndCode As Boolean = False

        Dim strSchool_Code As String = UCase(InputBox("Enter the school code", "RaceMgr - Add Team"))
        Do While Not bolFoundDup And Not bolEndCode

            For Each item As String In lstTeam.Items
                intPosition = InStr(1, item, "|")
                strTeamCodeIn = Mid(item, 1, intPosition - 1)
                If strTeamCodeIn = strSchool_Code Then
                    bolFoundDup = True
                    MsgBox("Found Duplicate School Code: " & strTeamCodeIn)
                End If
            Next
            If bolFoundDup Then
                strSchool_Code = UCase(InputBox("Enter a different school code", "RaceMgr - Add Team"))
                bolFoundDup = False
            Else
                bolEndCode = True
            End If
        Loop

        Dim strSchool_Name As String = InputBox("Enter the school name", "RaceMgr - Add Team")
        Dim strSchool_CoachFname As String = InputBox("Enter the Coach f-name", "RaceMgr - Add Team")
        Dim strSchool_CoachLname As String = InputBox("Enter the Coach l-name", "RaceMgr - Add Team")
        Dim strSchool_ADFname As String = InputBox("Enter the AD f-name", "RaceMgr - Add Team")
        Dim strSchool_ADLname As String = InputBox("Enter the AD l-name", "RaceMgr - Add Team")
        'Print to list box
        lstTeam.Items.Add(strSchool_Code & "|" & strSchool_Name & "|" & strSchool_CoachFname & "|" & strSchool_CoachLname & "|" & strSchool_ADFname & "|" & strSchool_ADLname)
    End Sub

    Private Sub btnDeleteRunner_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeleteRunner.Click
        'This routine removes a Team from the list based on the entered Team Code
        Dim answer As Integer
        answer = MsgBox("You're about to delete the selected team. Proceed?", vbQuestion + vbYesNo + vbDefaultButton2, "RaceMgr - Warning")
        If answer = vbYes Then
            'Remove the team from the list
            lstTeam.Items.Remove(lstTeam.SelectedItem)
        End If
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        If lstTeam.Items.Count > 0 And frmRM2000.lstPlayers.Items.Count > 0 Then
            frmRM0000.btnRaceMgr.Enabled = True
        Else
            frmRM0000.btnRaceMgr.Enabled = False
        End If
        frmRM0000.Show()
        Me.Hide()
    End Sub

    Private Sub frmRM1000_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If txtFilePath.Text.Trim = "" Then
            txtFilePath.Text = frmRM0000.txtFilePath.Text
        End If
    End Sub

    Private Sub frmRM1000_VisibleChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.VisibleChanged
        If txtFilePath.Text.Trim = "" Then
            txtFilePath.Text = frmRM0000.txtFilePath.Text
        End If
    End Sub
End Class