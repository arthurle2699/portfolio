﻿Imports System.IO

' Shell Author: Bob Desilets
' Modified by: Tien Le
' Module name: frmRM2000
' Last Modified date: 25-April-2020
' Module description: form 2000 runner mgr
Public Class frmRM2000
    Private Sub btnLoadRunners_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoadRunners.Click
        ' This routine loads the lstRunner box from an ASCII .txt file
        Dim strRow As String
        Dim bolFoundCode As Boolean = False
        Dim bolEndCode As Boolean = False
        Dim bolFoundDup As Boolean = False
        Dim intPosition As Integer
        Dim intPosition2 As Integer
        Dim strTeamCodeIn As String

        Dim textIn As StreamReader = New StreamReader(New FileStream(txtFilePath.Text, FileMode.OpenOrCreate, FileAccess.Read))

        ' Clear Team listbox
        lstPlayers.Items.Clear()

        Do While textIn.Peek <> -1 And Not bolEndCode
            Me.Refresh()
            strRow = textIn.ReadLine.Trim
            If Not bolFoundCode Then
                If "# ROSTER " = UCase(Mid(strRow, 1, 9)) Then
                    bolFoundCode = True
                End If
            Else
                If Mid(strRow, 1, 2) <> "# " Then
                    For Each item As String In lstPlayers.Items
                        intPosition = InStr(1, strRow, "|")
                        strTeamCodeIn = Mid(strRow, 1, intPosition - 1)
                        intPosition2 = InStr(1, item, strTeamCodeIn)
                        If intPosition2 > 0 Then
                            bolFoundDup = True
                            MsgBox("Found Duplicate runners BIB: " & strTeamCodeIn)
                        End If

                    Next
                    If Not bolFoundDup Then
                        lstPlayers.Items.Add(strRow)
                    Else
                        lstPlayers.Items.Add("DUPLICATE runners BIB: " & strRow)
                        lstPlayers.Items.Add("Please correct input file and reload teams")
                        bolEndCode = True
                    End If
                Else
                    bolEndCode = True
                End If
            End If
        Loop
        'Set focus on the first item
        lstPlayers.SelectedIndex = 0
    End Sub

    Private Sub btnAddRunners_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddRunners.Click
        ' This routine loops through a msg box prompting the user for Bib # | School Code | Name
        ' You must scan the existing runner's Bib #s for duplicates... Force the user 
        ' to enter a new number
        Dim bolDup As Boolean
        Dim strBIB_Input As String = InputBox("Enter the BIB number", "RaceMgr - Add Runner")
        Do
            bolDup = False
            For Each strBIB_Test As String In lstPlayers.Items
                If Equals(Mid(strBIB_Test, 1, 3), strBIB_Input) Then
                    bolDup = True
                End If
            Next
            If Not bolDup Then
                Dim strRoster_BIB As String = strBIB_Input
                Dim strRoster_SchoolCode As String = UCase(InputBox("Enter school code", "RaceMgr Add Runner"))
                Dim strRoster_RunnerFname As String = InputBox("Enter runner's f-name", "RaceMgr Add Runner")
                Dim strRoster_RunnerLname As String = InputBox("Enter runner's l-name", "RaceMgr Add Runner")
                lstPlayers.Items.Add(strRoster_BIB & "|" & strRoster_SchoolCode & "|" & strRoster_RunnerFname & "|" & strRoster_RunnerLname)
            Else
                strBIB_Input = InputBox("BIB number exist. Please enter a different BIB number", "RaceMgr - Add Runner")
            End If
        Loop While bolDup
    End Sub

    Private Sub btnDeleteRunner_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeleteRunner.Click
        'This routine removes a runner from the list based on the entered Bib #... Perform typical validation...
        Dim answer As Integer
        answer = MsgBox("You're about to delete the selected runner. Proceed?", vbQuestion + vbYesNo + vbDefaultButton2, "RaceMgr - Warning")
        If answer = vbYes Then
            'Remove the team from the list
            lstPlayers.Items.Remove(lstPlayers.SelectedItem)
        End If
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        If frmRM1000.lstTeam.Items.Count > 0 And lstPlayers.Items.Count > 0 Then
            frmRM0000.btnRaceMgr.Enabled = True
        Else
            frmRM0000.btnRaceMgr.Enabled = False
        End If
        frmRM0000.Show()
        Me.Hide()
    End Sub

    Private Sub frmRM2000_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If txtFilePath.Text.Trim = "" Then
            txtFilePath.Text = frmRM0000.txtFilePath.Text
        End If
    End Sub

    Private Sub frmRM2000_VisibleChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.VisibleChanged
        If txtFilePath.Text.Trim = "" Then
            txtFilePath.Text = frmRM0000.txtFilePath.Text
        End If
    End Sub
End Class